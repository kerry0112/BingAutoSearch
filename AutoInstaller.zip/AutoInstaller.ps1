$OutputEncoding = [System.Text.Encoding]::UTF8

# =================================================================================
#
# Script: Install-Common-Web-Browsers.ps1
#
# Description: This script automatically downloads and silently installs the latest
#              stable versions of popular web browsers: Microsoft Edge,
#              Google Chrome, Mozilla Firefox, Brave, and Supermium.
#
# Author:      Gemini
# Version:     1.0
# Date:        2025-08-22
#
# Instructions:
#              1. Save this code as a .ps1 file (e.g., Install-Browsers.ps1).
#              2. Right-click the file and select "Run with PowerShell".
#                 You may need to run it as an Administrator.
#
# =================================================================================

# --- Configuration ---

# 建立一個暫存下載目錄
$downloadPath = "$env:TEMP\BrowserDownloads"
if (-not (Test-Path -Path $downloadPath)) {
    New-Item -ItemType Directory -Path $downloadPath | Out-Null
}

Write-Host "檔案將會下載至: $downloadPath" -ForegroundColor Yellow

# 定義要下載和安裝的瀏覽器資訊
# 我們將使用 Winget 的 REST API 來獲取最新的下載連結，確保永遠是最新版本
function Get-WingetPackageUrl {
    param (
        [string]$packageId
    )
    try {
        $apiUrl = "https://api.winget.run/v2/packages/$packageId/versions/latest"
        $response = Invoke-RestMethod -Uri $apiUrl -Method Get
        # 尋找 64-bit 的 .exe 安裝程式
        $installer = $response.installers | Where-Object { $_.architecture -eq 'x64' -and $_.installerType -eq 'exe' } | Select-Object -First 1
        if ($installer) {
            return $installer.url
        } else {
            # 如果找不到 .exe，嘗試尋找 .msi
            $installer = $response.installers | Where-Object { $_.architecture -eq 'x64' -and $_.installerType -eq 'msi' } | Select-Object -First 1
            return $installer.url
        }
    }
    catch {
        Write-Error "無法獲取套件 '$packageId' 的下載連結。"
        return $null
    }
}

$browsers = @(
    @{
        Name = "Microsoft Edge"
        PackageId = "Microsoft.Edge"
        InstallerType = "exe"
        SilentArgs = "/silent /install"
        FileName = "EdgeInstaller.exe"
    },
    @{
        Name = "Google Chrome"
        PackageId = "Google.Chrome"
        InstallerType = "msi"
        SilentArgs = "/i `"{0}`" /qn" # {0} 將被替換為 MSI 檔案的路徑
        FileName = "ChromeInstaller.msi"
    },
    @{
        Name = "Mozilla Firefox"
        PackageId = "Mozilla.Firefox"
        InstallerType = "exe"
        SilentArgs = "-ms"
        FileName = "FirefoxInstaller.exe"
    },
    @{
        Name = "Brave"
        PackageId = "Brave.Brave"
        InstallerType = "exe"
        SilentArgs = "/silent /install"
        FileName = "BraveInstaller.exe"
    },
    @{
        Name = "Supermium"
        # Supermium 不在 Winget 上，我們直接使用 GitHub 的最新發行版連結
        Url = "https://github.com/win32ss/supermium/releases/latest/download/supermium_122_r1_32_setup.exe" # 注意：截至目前最新版，且為 32 位元
        InstallerType = "exe"
        SilentArgs = "/S" # 通常 Inno Setup 使用 /S
        FileName = "SupermiumInstaller.exe"
    }
)


# --- Execution ---

foreach ($browser in $browsers) {
    Write-Host "--------------------------------------------------" -ForegroundColor Green
    Write-Host "處理中: $($browser.Name)" -ForegroundColor Green
    Write-Host "--------------------------------------------------"

    $outputFile = Join-Path -Path $downloadPath -ChildPath $browser.FileName

    # 獲取下載連結
    if ($browser.PackageId) {
        Write-Host "正在從 Winget 來源獲取 $($browser.Name) 的最新下載連結..."
        $downloadUrl = Get-WingetPackageUrl -packageId $browser.PackageId
    } else {
        $downloadUrl = $browser.Url
    }

    if (-not $downloadUrl) {
        Write-Error "找不到 $($browser.Name) 的下載連結，跳過此項目。"
        continue
    }

    # 1. 下載安裝程式
    try {
        Write-Host "正在從 $downloadUrl 下載 $($browser.Name)..."
        Invoke-WebRequest -Uri $downloadUrl -OutFile $outputFile -UseBasicParsing
        Write-Host "$($browser.Name) 下載完成。" -ForegroundColor Cyan
    }
    catch {
        Write-Error "下載 $($browser.Name) 時發生錯誤: $_"
        continue # 跳到下一個瀏覽器
    }

    # 2. 執行靜默安裝
    try {
        Write-Host "正在靜默安裝 $($browser.Name)..."
        $installArgs = $browser.SilentArgs
        # 對於 MSI，需要將檔案路徑插入到參數中
        if ($browser.InstallerType -eq "msi") {
            $installArgs = [string]::Format($browser.SilentArgs, $outputFile)
        }

        if ($browser.InstallerType -eq "msi") {
            # MSI 使用 msiexec
            Start-Process msiexec.exe -ArgumentList $installArgs -Wait -Verb RunAs
        } else {
            # EXE 直接執行
            Start-Process -FilePath $outputFile -ArgumentList $installArgs -Wait -Verb RunAs
        }

        Write-Host "$($browser.Name) 已成功安裝。" -ForegroundColor Cyan
    }
    catch {
        Write-Error "安裝 $($browser.Name) 時發生錯誤: $_"
    }
}

# --- Cleanup ---
Write-Host "--------------------------------------------------" -ForegroundColor Green
Write-Host "所有安裝程序已完成。"
Write-Host "正在刪除暫存下載檔案..."
Remove-Item -Path $downloadPath -Recurse -Force
Write-Host "清理完成。" -ForegroundColor Green